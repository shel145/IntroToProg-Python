lstRow1 = ('book', 'low')
lstRow2 = ('poop', 'high')

lstRow = [lstRow1, lstRow2]

dicRow = {}
lstTable = []

for row in lstRow:
    task = row[0]
    priority = row[1]
    dicRow[task] = priority

lstTable.append(dicRow)

print(lstTable)

for key, values in dicRow.items():
    strLine = key, ",", values
    objToDo = open("Test.txt", "w+")
    # write to file
    for key, values in dicRow.items():
        objToDo.writeline([key, values])

input("enter")
